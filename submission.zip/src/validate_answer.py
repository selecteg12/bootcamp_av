"""Strict validation for the submitted benchmark answer.csv."""
from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path

import pandas as pd


def validate_answer(answer_path: str | Path, queries_path: str | Path, items_path: str | Path) -> None:
    answer_path = Path(answer_path)
    queries = pd.read_parquet(queries_path, columns=["query_id"])
    items = pd.read_parquet(items_path, columns=["item_id"])
    query_ids = queries["query_id"].astype("string").tolist()
    item_ids = items["item_id"].astype("string").tolist()
    if len(query_ids) != 2452:
        raise AssertionError(f"Expected 2452 benchmark queries, found {len(query_ids)}")

    with answer_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
        except StopIteration as exc:
            raise AssertionError("answer.csv is empty") from exc
        if header != ["query_id", "answer"]:
            raise AssertionError(f"Expected exactly query_id,answer columns; found {header!r}")
        rows = list(reader)
    if len(rows) != len(query_ids):
        raise AssertionError(f"Expected {len(query_ids)} data rows, found {len(rows)}")
    if any(len(row) != 2 for row in rows):
        bad = next(i + 2 for i, row in enumerate(rows) if len(row) != 2)
        raise AssertionError(f"CSV row {bad} has {len(rows[bad - 2])} columns, expected 2")

    written_query_ids = [row[0] for row in rows]
    expected_counts = Counter(str(value) for value in query_ids)
    observed_counts = Counter(written_query_ids)
    if observed_counts != expected_counts:
        missing = list((expected_counts - observed_counts).elements())[:5]
        extra = list((observed_counts - expected_counts).elements())[:5]
        raise AssertionError(f"query_id mismatch (missing={missing}, extra={extra})")
    if any(count != 1 for count in observed_counts.values()):
        raise AssertionError("Each benchmark query_id must occur exactly once")

    catalog = set(str(value) for value in item_ids)
    for line_no, (query_id, answer) in enumerate(rows, start=2):
        if not isinstance(answer, str):
            raise AssertionError(f"answer must be a string at CSV row {line_no}")
        if any(char in answer for char in "[],"):
            raise AssertionError(f"answer contains forbidden list punctuation at CSV row {line_no}")
        tokens = answer.split()
        if len(tokens) > 50:
            raise AssertionError(f"More than 50 item_ids at CSV row {line_no}")
        if answer != " ".join(tokens):
            raise AssertionError(f"answer must use single spaces between item_ids at CSV row {line_no}")
        if len(tokens) != len(set(tokens)):
            raise AssertionError(f"Duplicate item_id at CSV row {line_no}")
        invalid = [value for value in tokens if value not in catalog]
        if invalid:
            raise AssertionError(f"Unknown or case-changed item_id at CSV row {line_no}: {invalid[0]!r}")

    roundtrip = pd.read_csv(answer_path, dtype={"query_id": "string", "answer": "string"}, keep_default_na=False)
    if roundtrip.columns.tolist() != ["query_id", "answer"] or len(roundtrip) != len(rows):
        raise AssertionError("CSV round-trip changed its shape or columns")
    for i, (query_id, answer) in enumerate(rows):
        if roundtrip.iloc[i]["query_id"] != query_id or roundtrip.iloc[i]["answer"] != answer:
            raise AssertionError(f"CSV round-trip changed data at row {i + 2}")
    if any(col.lower().startswith("unnamed:") for col in roundtrip.columns):
        raise AssertionError("Unexpected index column in answer.csv")


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    validate_answer(root / "answer.csv", root / "benchmark_queries.parquet", root / "benchmark_items.parquet")
    print("answer.csv validation passed: 2,452 unique queries, valid catalog item IDs, at most 50 items each.")


if __name__ == "__main__":
    main()
