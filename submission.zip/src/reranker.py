"""Leakage-safe candidate generation, hard-negative sampling and LightGBM."""
from __future__ import annotations

import gc

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from lightgbm import LGBMClassifier, LGBMRanker

from .features import feature_frame
from .preprocessing import normalize_query, normalize_text
from .retrieval_experiments import top_sparse_scores, union_rankings

SEED = 42


def query_view(frame: pd.DataFrame) -> pd.DataFrame:
    """One reproducible feature row per normalized query."""
    view = frame.copy()
    view["_query_key"] = view["search_query"].map(normalize_query)
    return view.drop_duplicates("_query_key", keep="first").set_index("_query_key", drop=True)


def _item_docs(items: pd.DataFrame, fields, title_boost=False, char_limit=None):
    normalized = {field: items[field].fillna("").map(normalize_text).tolist() for field in fields}
    docs = []
    for i in range(len(items)):
        parts = []
        for field in fields:
            value = normalized[field][i]
            if char_limit is not None:
                value = value[:char_limit]
            parts.append(value)
            if title_boost and field == "item_title_raw":
                parts.append(value)
        docs.append(" ".join(parts))
    return docs


def _query_docs(queries: pd.DataFrame):
    return [normalize_text(f"{row['search_query']} {row.get('search_infm_params_text', '')}") for _, row in queries.iterrows()]


def item_source_scores(items: pd.DataFrame, queries: pd.DataFrame):
    """Get BM25 and best prior char-TF-IDF ranks/scores over fixed catalog."""
    ids = items["item_id"].astype(str).tolist()
    texts = _query_docs(queries)
    all_scores: dict[str, dict[str, list[tuple[str, float]]]] = {str(q): {} for q in queries.index}

    # BM25 Okapi; title duplication is the simple title field boost.
    docs = _item_docs(items, ("item_title_raw", "item_infm_params_text", "item_description_raw"), title_boost=True)
    cv = CountVectorizer(ngram_range=(1, 1), min_df=1, max_features=500_000, dtype=np.float32)
    counts = cv.fit_transform(docs).tocsr()
    n_docs = counts.shape[0]
    dfreq = np.asarray((counts > 0).sum(axis=0)).ravel()
    idf = np.log(1.0 + (n_docs - dfreq + .5) / (dfreq + .5)).astype(np.float32)
    lengths = np.asarray(counts.sum(axis=1)).ravel().astype(np.float32)
    k1, b = 1.2, .75
    row_idx = np.repeat(np.arange(n_docs), np.diff(counts.indptr))
    norm = k1 * (1.0 - b + b * lengths[row_idx] / max(float(lengths.mean()), 1.0))
    counts.data = counts.data * (k1 + 1.0) / (counts.data + norm) * idf[counts.indices]
    qmat = cv.transform(texts).tocsr()
    scores = top_sparse_scores(qmat, counts, ids, top_k=500, batch_size=12)
    for i, q in enumerate(queries.index.astype(str)):
        all_scores[q]["bm25"] = scores[i]
    del docs, cv, counts, qmat, scores
    gc.collect()

    # The char model's fields are capped, as in the retrieval experiment.
    docs = _item_docs(items, ("item_title_raw", "item_infm_params_text", "item_description_raw"), char_limit=256)
    vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=100_000, dtype=np.float32, sublinear_tf=True)
    doc_matrix = vectorizer.fit_transform(docs).tocsr()
    qmat = vectorizer.transform(texts).tocsr()
    scores = top_sparse_scores(qmat, doc_matrix, ids, top_k=500, batch_size=12)
    for i, q in enumerate(queries.index.astype(str)):
        all_scores[q]["tfidf"] = scores[i]
    del docs, vectorizer, doc_matrix, qmat, scores
    gc.collect()
    return all_scores


def similar_source_scores(fit: pd.DataFrame, queries: pd.DataFrame, candidate_ids: set[str], top_neighbors=50):
    train = fit.copy()
    train["_query_key"] = train["search_query"].map(normalize_query)
    grouped = train.groupby("_query_key", sort=True)
    train_queries = [str(q) for q in grouped.size().index]
    items_by_query = {str(q): set(group["item_id"].astype(str)) & candidate_ids for q, group in grouped}
    # Output keys may be normalized query strings (training/validation) or
    # query_id strings (benchmark inference). Similarity always uses the actual
    # search text, while map keys remain unique for each inference row.
    query_text_by_key = {
        str(key): str(row.get("search_query", key) or "")
        for key, row in queries.iterrows()
    }
    val_text = [normalize_text(query_text_by_key[str(key)]) for key in queries.index]
    ranked_neighbors = []
    for vectorizer in (
        TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_features=300_000, dtype=np.float32, sublinear_tf=True),
        TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=300_000, dtype=np.float32, sublinear_tf=True),
    ):
        fit_matrix = vectorizer.fit_transform(train_queries)
        val_matrix = vectorizer.transform(val_text)
        ranked_neighbors.append(top_sparse_scores(val_matrix, fit_matrix, train_queries, top_k=top_neighbors + 1, batch_size=24))
        del vectorizer, fit_matrix, val_matrix
    result = {}
    for i, q in enumerate(queries.index.astype(str)):
        normalized_q = normalize_query(query_text_by_key[q])
        item_scores = {}
        for neighbor_ranks in ranked_neighbors:
            selected = [(neighbor, score) for neighbor, score in neighbor_ranks[i] if neighbor != normalized_q][:top_neighbors]
            for neighbor, score in selected:
                for item_id in items_by_query.get(neighbor, ()):
                    item_scores[item_id] = max(score, item_scores.get(item_id, 0.0))
        result[q] = sorted(item_scores.items(), key=lambda x: (-x[1], x[0]))[:500]
    del ranked_neighbors
    return result


def _rank_feature_map(scored: dict[str, list[tuple[str, float]]]):
    out = {}
    for q, ranked in scored.items():
        out[q] = {item_id: (float(score), rank) for rank, (item_id, score) in enumerate(ranked, 1)}
    return out


def build_candidate_pool(fit: pd.DataFrame, queries: pd.DataFrame, items: pd.DataFrame, item_scores, max_pool=500):
    """Generate exact + similar + BM25 + TF-IDF candidates from fit only."""
    ids = set(items["item_id"].astype(str))
    similar = similar_source_scores(fit, queries, ids, 50)
    exact_group = fit.assign(_query_key=fit["search_query"].map(normalize_query)).groupby("_query_key", sort=False)["item_id"]
    exact = {str(q): list(dict.fromkeys(str(x) for x in vals if str(x) in ids))[:500] for q, vals in exact_group}
    query_norms = {
        str(key): normalize_query(row.get("search_query", key))
        for key, row in queries.iterrows()
    }
    sources_scored = {
        q: item_scores.get(q, {}) for q in queries.index.astype(str)
    }
    source_ranked = {
        "exact_query": {q: [(item, 1.0) for item in exact.get(query_norms[q], [])] for q in queries.index.astype(str)},
        "similar_query": similar,
        "bm25": {q: sources_scored[q].get("bm25", []) for q in sources_scored},
        "tfidf": {q: sources_scored[q].get("tfidf", []) for q in sources_scored},
    }
    ranked_ids = {
        name: {q: [item for item, _ in vals] for q, vals in ranks.items()}
        for name, ranks in source_ranked.items()
    }
    pools = union_rankings(
        [ranked_ids["exact_query"], ranked_ids["similar_query"], ranked_ids["bm25"], ranked_ids["tfidf"]],
        list(queries.index.astype(str)), max_k=max_pool,
    )
    rank_maps = {name: _rank_feature_map(ranks) for name, ranks in source_ranked.items()}
    retrieval_features = {
        q: {source: rank_maps[source].get(q, {}) for source in rank_maps}
        for q in pools
    }
    return pools, retrieval_features, source_ranked


def labeled_candidate_rows(
    queries: pd.DataFrame,
    pools: dict[str, list[str]],
    retrieval_features,
    items: pd.DataFrame,
    positives: dict[str, set[str]],
    negatives_per_positive=10,
    seed=SEED,
    negative_only=False,
):
    """Keep all pool positives and sample only retrieval-generated hard negatives."""
    rng = np.random.default_rng(seed)
    sampled = {}
    for q, candidates in pools.items():
        positive = [x for x in candidates if x in positives.get(q, set())]
        negatives = [x for x in candidates if x not in positives.get(q, set())]
        if not positive:
            continue
        n = min(len(negatives), negatives_per_positive * len(positive))
        if n < len(negatives):
            chosen = rng.choice(len(negatives), size=n, replace=False)
            negatives = [negatives[i] for i in chosen]
        sampled[q] = positive + negatives
    frame = feature_frame(queries, sampled, items, retrieval_features)
    if frame.empty:
        frame["label"] = []
        return frame
    frame["label"] = [int(item in positives.get(q, set())) for q, item in zip(frame["query_key"], frame["item_id"])]
    return frame


def fit_classifier(train_frame: pd.DataFrame, features: list[str], seed=SEED):
    model = LGBMClassifier(
        objective="binary", n_estimators=300, learning_rate=0.05, num_leaves=31,
        max_depth=-1, min_child_samples=30, subsample=0.9, colsample_bytree=0.9,
        reg_lambda=1.0, random_state=seed, n_jobs=-1, verbosity=-1,
    )
    model.fit(train_frame[features], train_frame["label"].astype(int))
    return model


def fit_ranker(train_frame: pd.DataFrame, features: list[str], seed=SEED):
    ordered = train_frame.sort_values("query_key", kind="stable")
    group = ordered.groupby("query_key", sort=False).size().to_numpy()
    model = LGBMRanker(
        objective="lambdarank", metric="ndcg", n_estimators=250, learning_rate=0.05,
        num_leaves=31, min_child_samples=30, subsample=0.9, colsample_bytree=0.9,
        reg_lambda=1.0, random_state=seed, n_jobs=-1, verbosity=-1,
    )
    model.fit(ordered[features], ordered["label"].astype(int), group=group)
    return model


def rerank_candidates(model, rows: pd.DataFrame, features: list[str], top_k=50):
    scores = model.predict(rows[features], num_threads=-1)
    scored = rows[["query_key", "item_id"]].copy()
    scored["score"] = scores
    out = {}
    for q, group in scored.groupby("query_key", sort=False):
        out[str(q)] = group.sort_values(["score", "item_id"], ascending=[False, True], kind="stable")["item_id"].head(top_k).astype(str).tolist()
    return out
