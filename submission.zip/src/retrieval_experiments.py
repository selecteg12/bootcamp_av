"""Sparse candidate generation and leakage-safe retrieval evaluation."""
from __future__ import annotations

from collections import defaultdict

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

from .preprocessing import normalize_text, normalize_query

K_VALUES = (5, 10, 20, 50)
ITEM_K_VALUES = (50, 100, 200, 500)


def unique_validation_queries(frame: pd.DataFrame) -> pd.DataFrame:
    q = frame.assign(_query=frame["search_query"].map(normalize_query))
    cols = ["_query", "search_query", "search_infm_params_text"]
    return q[cols].drop_duplicates("_query").set_index("_query", drop=False)


def exact_rankings(fit: pd.DataFrame, queries: pd.DataFrame, candidate_ids: set[str]) -> dict[str, list[str]]:
    grouped = fit.assign(_query=fit["search_query"].map(normalize_query)).groupby("_query", sort=False)["item_id"]
    index = {str(q): list(dict.fromkeys(str(x) for x in values if str(x) in candidate_ids)) for q, values in grouped}
    return {str(q): index.get(str(q), [])[:500] for q in queries.index}


def recall_at_k(rankings: dict[str, list[str]], truth: dict[str, set[str]], k: int) -> float:
    if not truth:
        return 0.0
    values = [len(set(rankings.get(q, [])[:k]) & relevant) / len(relevant) for q, relevant in truth.items() if relevant]
    return float(np.mean(values)) if values else 0.0


def union_rankings(sources: list[dict[str, list[str]]], query_ids, max_k: int = 500) -> dict[str, list[str]]:
    """Deterministic round-robin union keeps one source from flooding the pool."""
    result = {}
    for q in query_ids:
        merged, seen = [], set()
        depth = 0
        while len(merged) < max_k:
            added = False
            for source in sources:
                ranking = source.get(q, [])
                if depth < len(ranking):
                    item = ranking[depth]
                    if item not in seen:
                        seen.add(item)
                        merged.append(item)
                        added = True
                        if len(merged) >= max_k:
                            break
            if not added and all(depth >= len(s.get(q, [])) for s in sources):
                break
            depth += 1
        result[q] = merged
    return result


def top_sparse_scores(query_matrix, doc_matrix, item_ids: list[str], top_k: int = 500, batch_size: int = 12):
    """Sparse cosine/linear retrieval, materializing only small query batches."""
    result: dict[str, list[tuple[str, float]]] = {}
    for start in range(0, query_matrix.shape[0], batch_size):
        scores = (query_matrix[start : start + batch_size] @ doc_matrix.T).toarray()
        for local, row in enumerate(scores):
            positive = np.flatnonzero(row > 0)
            if len(positive) > top_k:
                chosen = positive[np.argpartition(row[positive], -top_k)[-top_k:]]
            else:
                chosen = positive
            ordered = sorted(((item_ids[i], float(row[i])) for i in chosen), key=lambda x: (-x[1], x[0]))
            result[start + local] = ordered
    return result


def similar_query_rankings(fit: pd.DataFrame, queries: pd.DataFrame, candidate_ids: set[str], analyzer: str):
    fit_q = fit.assign(_query=fit["search_query"].map(normalize_query))
    # Per-query item sets prevent repeated click rows from inflating a neighbor.
    groups = fit_q.groupby("_query", sort=True)
    fit_query_ids = list(groups.size().index.astype(str))
    item_map = {
        str(q): set(str(v) for v in group["item_id"].unique()) & candidate_ids
        for q, group in groups
    }
    q_fit = [normalize_text(q) for q in fit_query_ids]
    q_val = [normalize_text(q) for q in queries.index]
    if analyzer == "word":
        vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_features=300_000, dtype=np.float32, sublinear_tf=True)
    else:
        vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=300_000, dtype=np.float32, sublinear_tf=True)
    fit_matrix = vectorizer.fit_transform(q_fit)
    val_matrix = vectorizer.transform(q_val)
    # TF-IDF rows are L2-normalized, so this sparse product is cosine similarity.
    similarities = top_sparse_scores(val_matrix, fit_matrix, fit_query_ids, top_k=51, batch_size=24)
    output = {k: {} for k in K_VALUES}
    for row_i, query in enumerate(queries.index.astype(str)):
        neighbors = [(q, score) for q, score in similarities[row_i] if q != query][:50]
        for k in K_VALUES:
            item_scores: dict[str, float] = {}
            for neighbor, score in neighbors[:k]:
                for item in item_map.get(neighbor, ()):
                    if score > item_scores.get(item, -1.0):
                        item_scores[item] = score
            output[k][query] = [item for item, _ in sorted(item_scores.items(), key=lambda x: (-x[1], x[0]))[:500]]
        
    del fit_matrix, val_matrix, vectorizer
    return output


def query_texts(queries: pd.DataFrame) -> list[str]:
    return [normalize_text(f"{row.search_query} {row.search_infm_params_text}") for row in queries.itertuples()]


def item_texts(items: pd.DataFrame, fields: tuple[str, ...], normalized_fields=None, field_char_limit: int | None = None) -> list[str]:
    # Doubling title is a transparent, simple BM25 field emphasis.
    docs = []
    for i, row in enumerate(items.itertuples(index=False)):
        chunks = []
        for field in fields:
            value = normalized_fields[field][i] if normalized_fields is not None else normalize_text(getattr(row, field))
            if field_char_limit is not None:
                value = value[:field_char_limit]
            if field == "item_title_raw":
                chunks.extend([value, value])
            else:
                chunks.append(value)
        docs.append(" ".join(chunks))
    return docs


def bm25_rankings(items: pd.DataFrame, queries: pd.DataFrame, normalized_fields=None) -> dict[str, list[str]]:
    fields = ("item_title_raw", "item_infm_params_text", "item_description_raw")
    docs = item_texts(items, fields, normalized_fields)
    vectorizer = CountVectorizer(ngram_range=(1, 1), min_df=1, max_features=500_000, dtype=np.float32)
    counts = vectorizer.fit_transform(docs).tocsr()
    n_docs = counts.shape[0]
    df = np.asarray((counts > 0).sum(axis=0)).ravel()
    idf = np.log(1.0 + (n_docs - df + 0.5) / (df + 0.5)).astype(np.float32)
    lengths = np.asarray(counts.sum(axis=1)).ravel().astype(np.float32)
    avgdl = float(lengths.mean())
    k1, b = 1.2, 0.75
    row_indices = np.repeat(np.arange(n_docs), np.diff(counts.indptr))
    norm = k1 * (1.0 - b + b * lengths[row_indices] / max(avgdl, 1.0))
    counts.data = counts.data * (k1 + 1.0) / (counts.data + norm) * idf[counts.indices]
    query_matrix = vectorizer.transform(query_texts(queries)).tocsr()
    scores = top_sparse_scores(query_matrix, counts, items["item_id"].astype(str).tolist(), top_k=500, batch_size=12)
    return {str(q): [item for item, _ in scores[i]] for i, q in enumerate(queries.index)}


def tfidf_item_rankings(items: pd.DataFrame, queries: pd.DataFrame, analyzer: str, fields: tuple[str, ...], normalized_fields=None):
    if analyzer == "word":
        vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=500_000, dtype=np.float32, sublinear_tf=True)
        docs = item_texts(items, fields, normalized_fields)
    else:
        vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=100_000, dtype=np.float32, sublinear_tf=True)
        # Character models are expensive on long free-form text; cap each field
        # equally so title/params/description remain comparable and reproducible.
        docs = item_texts(items, fields, normalized_fields, field_char_limit=256)
    doc_matrix = vectorizer.fit_transform(docs).tocsr()
    query_matrix = vectorizer.transform(query_texts(queries)).tocsr()
    scores = top_sparse_scores(query_matrix, doc_matrix, items["item_id"].astype(str).tolist(), top_k=500, batch_size=12)
    result = {str(q): [item for item, _ in scores[i]] for i, q in enumerate(queries.index)}
    del docs, doc_matrix, query_matrix, vectorizer
    return result


def experiment_scenario(name: str, fit: pd.DataFrame, validation: pd.DataFrame, items: pd.DataFrame, truth: dict[str, set[str]]):
    candidate_ids = set(items["item_id"].astype(str))
    queries = unique_validation_queries(validation)
    queries = queries.loc[queries.index.intersection(list(ground_truth_query_ids(truth)))]
    query_ids = list(queries.index.astype(str))
    rankings = {}
    rankings["exact"] = exact_rankings(fit, queries, candidate_ids)
    print(f"[{name}] similar-query word", flush=True)
    word_sim = similar_query_rankings(fit, queries, candidate_ids, "word")
    print(f"[{name}] similar-query char", flush=True)
    char_sim = similar_query_rankings(fit, queries, candidate_ids, "char")
    for k in K_VALUES:
        rankings[f"similar_word@{k}"] = word_sim[k]
        rankings[f"similar_char@{k}"] = char_sim[k]
        rankings[f"similar@{k}"] = union_rankings([word_sim[k], char_sim[k]], query_ids)

    print(f"[{name}] normalize item text fields", flush=True)
    normalized_fields = {
        field: items[field].fillna("").map(normalize_text).tolist()
        for field in ("item_title_raw", "item_infm_params_text", "item_description_raw")
    }
    print(f"[{name}] BM25", flush=True)
    rankings["BM25"] = bm25_rankings(items, queries, normalized_fields)
    for analyzer in ("word", "char"):
        for fields, suffix in [
            (("item_title_raw",), "title"),
            (("item_title_raw", "item_infm_params_text"), "title_params"),
            (("item_title_raw", "item_infm_params_text", "item_description_raw"), "title_params_desc"),
        ]:
            label = f"TFIDF_{analyzer}_{suffix}"
            print(f"[{name}] {label}", flush=True)
            rankings[label] = tfidf_item_rankings(items, queries, analyzer, fields, normalized_fields)

    # Pick standalone best similar and TF-IDF variants on validation for clear unions.
    sim_labels = [f"similar@{k}" for k in K_VALUES]
    best_sim = max(sim_labels, key=lambda label: recall_at_k(rankings[label], truth, 50))
    tfidf_labels = [k for k in rankings if k.startswith("TFIDF_")]
    best_tfidf = max(tfidf_labels, key=lambda label: recall_at_k(rankings[label], truth, 50))
    sources = {
        "exact": rankings["exact"],
        "similar-query": rankings[best_sim],
        "BM25": rankings["BM25"],
        "TF-IDF": rankings[best_tfidf],
    }
    combinations = {
        "exact": ["exact"],
        "similar-query": ["similar-query"],
        "BM25": ["BM25"],
        "TF-IDF": ["TF-IDF"],
        "exact + similar": ["exact", "similar-query"],
        "exact + BM25": ["exact", "BM25"],
        "similar + BM25": ["similar-query", "BM25"],
        "all": ["exact", "similar-query", "BM25", "TF-IDF"],
    }
    final_rankings = dict(sources)
    for label, members in combinations.items():
        if len(members) > 1:
            final_rankings[label] = union_rankings([sources[m] for m in members], query_ids)
    return rankings, final_rankings, {"best_similar": best_sim, "best_tfidf": best_tfidf}, query_ids


def ground_truth_query_ids(truth: dict[str, set[str]]):
    return truth.keys()
