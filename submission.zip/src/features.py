"""Inference-available query/item features for the first-stage reranker."""
from __future__ import annotations

from difflib import SequenceMatcher
import math

import numpy as np
import pandas as pd

from .preprocessing import normalize_text, normalize_query

RETRIEVAL_SOURCES = ("bm25", "similar_query", "tfidf", "exact_query")


def _tokens(value: object) -> set[str]:
    return set(normalize_text(value).split())


def _overlap(left: set[str], right: set[str]) -> tuple[int, float, float]:
    common = left & right
    union = left | right
    return len(common), len(common) / len(left) if left else 0.0, len(common) / len(union) if union else 0.0


def _log_numeric(value: object) -> float:
    try:
        number = float(value)
        if not math.isfinite(number):
            return 0.0
        return float(np.sign(number) * np.log1p(abs(number)))
    except (TypeError, ValueError, OverflowError):
        return 0.0


def pair_features(
    query: pd.Series,
    item: pd.Series,
    retrieval: dict[str, dict[str, tuple[float, int]]],
) -> dict[str, float]:
    """Build features from fields available for the query and catalog item."""
    item_id = str(item["item_id"])
    feats: dict[str, float] = {}
    present = 0
    for source in RETRIEVAL_SOURCES:
        hit = retrieval.get(source, {}).get(item_id)
        feats[f"{source}_present"] = float(hit is not None)
        feats[f"{source}_rank"] = float(hit[1]) if hit is not None else 0.0
        feats[f"{source}_score"] = float(hit[0]) if hit is not None else 0.0
        present += hit is not None
    feats["number_of_retrieval_sources"] = float(present)
    feats["exact_query_match"] = float(feats["exact_query_present"] > 0)

    q_tokens = _tokens(query["search_query"])
    title_tokens = _tokens(item.get("item_title_raw", ""))
    desc_tokens = _tokens(item.get("item_description_raw", ""))
    item_param_tokens = _tokens(item.get("item_infm_params_text", ""))
    search_param_tokens = _tokens(query.get("search_infm_params_text", ""))
    all_item_tokens = title_tokens | desc_tokens | item_param_tokens
    for name, tokens in (("title", title_tokens), ("description", desc_tokens), ("params", item_param_tokens)):
        count, query_fraction, jaccard = _overlap(q_tokens, tokens)
        feats[f"query_{name}_matched_tokens"] = float(count)
        feats[f"query_{name}_token_recall"] = query_fraction
        feats[f"query_{name}_jaccard"] = jaccard
    count_all, query_fraction_all, _ = _overlap(q_tokens, all_item_tokens)
    feats["query_all_matched_tokens"] = float(count_all)
    feats["query_token_recall_all"] = query_fraction_all
    param_count, param_recall, param_jaccard = _overlap(search_param_tokens, item_param_tokens)
    feats["search_item_params_matched_tokens"] = float(param_count)
    feats["search_item_params_recall"] = param_recall
    feats["search_item_params_jaccard"] = param_jaccard
    q_text = normalize_text(query["search_query"])
    title_text = normalize_text(item.get("item_title_raw", ""))
    feats["query_title_char_similarity"] = SequenceMatcher(None, q_text, title_text, autojunk=False).ratio()
    feats["query_length_chars"] = float(len(q_text))
    feats["title_length_chars"] = float(len(title_text))
    feats["description_length_chars"] = float(len(str(item.get("item_description_raw", "") or "")))

    feats["category_match"] = float(query.get("search_category") == item.get("item_category_id"))
    feats["location_match"] = float(query.get("search_location_id") == item.get("item_location_id"))
    feats["search_is_delivery_search"] = float(query.get("search_is_delivery_search", 0) or 0)
    feats["item_is_phone_hidden"] = float(bool(item.get("item_is_phone_hidden", False)))
    feats["item_is_message_forbidden"] = float(bool(item.get("item_is_message_forbidden", False)))
    feats["item_price_log1p"] = _log_numeric(item.get("item_price"))
    feats["item_rating_log1p"] = _log_numeric(item.get("item_rating"))
    feats["item_rating_reviews_count_log1p"] = _log_numeric(item.get("item_rating_reviews_count"))
    return feats


def feature_frame(
    queries: pd.DataFrame,
    candidates: dict[str, list[str]],
    items: pd.DataFrame,
    retrieval_features: dict[str, dict[str, dict[str, tuple[float, int]]]],
) -> pd.DataFrame:
    """Extract one feature row per query-candidate pair."""
    needed_items = {item_id for item_ids in candidates.values() for item_id in item_ids}
    item_rows = {
        str(row.item_id): row._asdict()
        for row in items.loc[items["item_id"].astype(str).isin(needed_items)].itertuples(index=False)
    }
    query_rows = {normalize_query(row["search_query"]): row for _, row in queries.iterrows()}
    records = []
    for qid, item_ids in candidates.items():
        # Candidate keys are normalized texts in validation and query_id strings
        # at final inference. Prefer the exact indexed row when it exists.
        if qid in queries.index:
            query = queries.loc[qid]
            if isinstance(query, pd.DataFrame):
                query = query.iloc[0]
        else:
            query = query_rows[qid]
        sources = retrieval_features.get(qid, {})
        for item_id in item_ids:
            item = item_rows[item_id]
            record = pair_features(query, item, sources)
            record["query_key"] = qid
            record["item_id"] = item_id
            records.append(record)
    frame = pd.DataFrame.from_records(records)
    if frame.empty:
        return frame
    for col in frame.columns:
        if col not in ("query_key", "item_id"):
            frame[col] = frame[col].replace([np.inf, -np.inf], np.nan).fillna(0).astype(np.float32)
    return frame
