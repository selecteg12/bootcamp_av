"""Text normalization helpers shared by retrieval and evaluation."""
from __future__ import annotations

import re
import unicodedata


def normalize_query(value: object) -> str:
    """Normalize a query conservatively: Unicode, case, ё/е and punctuation."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value)).lower().replace("ё", "е")
    text = re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def normalize_text(value: object) -> str:
    """Normalize an arbitrary text field without stemming or lemmatization."""
    return normalize_query(value)
