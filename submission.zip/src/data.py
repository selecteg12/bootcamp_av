"""Loading of the provided Parquet datasets with string identifiers."""
from pathlib import Path

import pandas as pd


def load_train(path: str | Path) -> pd.DataFrame:
    frame = pd.read_parquet(path)
    frame["item_id"] = frame["item_id"].astype("string")
    return frame
