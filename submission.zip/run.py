"""Train the final leakage-safe LambdaRank model and write benchmark answer.csv."""
from __future__ import annotations

import gc
import os
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

from src.data import load_train
from src.features import feature_frame
from src.preprocessing import normalize_query
from src.reranker import (
    SEED,
    build_candidate_pool,
    fit_ranker,
    item_source_scores,
    labeled_candidate_rows,
    query_view,
    rerank_candidates,
)
from src.validate_answer import validate_answer

ROOT = Path(__file__).resolve().parent


def _benchmark_view(queries: pd.DataFrame) -> pd.DataFrame:
    # Keep each benchmark query_id as its key, even if two rows have the same
    # normalized text but different location or filter parameters.
    return queries.set_index("query_id", drop=False)


def _pair_holdout_folds(frame: pd.DataFrame, n_folds: int = 2) -> list[tuple[pd.DataFrame, pd.DataFrame]]:
    """Assign every unique query-item pair to exactly one target fold.

    Repeated interaction rows for a pair stay together. Within each normalized
    query, shuffled pairs are round-robin assigned, so a query with multiple
    positives generally retains historical items in the other fold. A singleton
    query is target in one fold and absent from that fold's fit, as in unseen
    query validation.
    """
    pairs = frame[["search_query", "item_id"]].copy()
    pairs["_query"] = pairs["search_query"].map(normalize_query)
    pairs["item_id"] = pairs["item_id"].astype(str)
    unique_pairs = pairs[["_query", "item_id"]].drop_duplicates()
    rng = np.random.default_rng(SEED)
    assignments: dict[tuple[str, str], int] = {}
    for query, group in unique_pairs.groupby("_query", sort=True):
        values = group["item_id"].to_numpy(copy=True)
        rng.shuffle(values)
        offset = int(rng.integers(n_folds))
        for i, item_id in enumerate(values):
            assignments[(str(query), str(item_id))] = (i + offset) % n_folds
    normalized = frame["search_query"].map(normalize_query)
    item_ids = frame["item_id"].astype(str)
    row_fold = [assignments[(str(q), str(item))] for q, item in zip(normalized, item_ids)]
    result = []
    for fold_id in range(n_folds):
        target_mask = pd.Series(row_fold, index=frame.index).eq(fold_id)
        result.append((frame.loc[~target_mask].copy(), frame.loc[target_mask].copy()))
    return result


def _load_or_extend_score_cache(items: pd.DataFrame, train_view: pd.DataFrame, benchmark_view: pd.DataFrame):
    cache_path = ROOT / "reranker_item_scores.pkl"
    cached = {}
    if cache_path.exists():
        with cache_path.open("rb") as handle:
            cached = pickle.load(handle)
        cached = {str(key): value for key, value in cached.items()}

    # Prefer the benchmark row's query parameters where a normalized query occurs
    # in both datasets. This reflects the exact input available at inference.
    combined = pd.concat([benchmark_view, train_view.loc[~train_view.index.isin(benchmark_view.index)]])
    missing_keys = [key for key in combined.index.astype(str) if key not in cached]
    if missing_keys:
        print(f"Building item retrieval scores for {len(missing_keys):,} uncached query keys; cached keys={len(cached):,}.", flush=True)
        missing = combined.loc[missing_keys]
        fresh = item_source_scores(items, missing)
        cached.update(fresh)
        temp_path = cache_path.with_suffix(".pkl.tmp")
        with temp_path.open("wb") as handle:
            pickle.dump(cached, handle, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(temp_path, cache_path)
    else:
        print(f"Reusing item retrieval score cache ({len(cached):,} query keys).", flush=True)
    return cached


def main() -> None:
    train = load_train(ROOT / "train.parquet")
    items = pd.read_parquet(ROOT / "benchmark_items.parquet")
    queries = pd.read_parquet(ROOT / "benchmark_queries.parquet")
    train["item_id"] = train["item_id"].astype("string")
    items["item_id"] = items["item_id"].astype("string")
    queries["query_id"] = queries["query_id"].astype("string")
    candidate_ids = set(items["item_id"].astype(str))

    # A filtered view retains the original train file and only labels positives
    # whose item is in the exact catalog available at inference.
    filtered = train.loc[train["item_id"].astype(str).isin(candidate_ids)].copy()
    filtered["item_id"] = filtered["item_id"].astype("string")
    filtered.to_parquet(ROOT / "filtered_train_benchmark_items.parquet", index=False)
    print(f"Usable train rows={len(filtered):,}; unique pairs={len(filtered[['search_query','item_id']].drop_duplicates()):,}.", flush=True)

    # Pair-disjoint cross-fitting creates leakage-free candidates and ensures
    # every catalog-covered train pair supplies a target label in exactly one
    # fold. The target pair is absent from its fold's exact/similar fit history.
    train_view = query_view(filtered)
    benchmark_view = _benchmark_view(queries)
    score_cache = _load_or_extend_score_cache(items, train_view, benchmark_view)

    training_frames = []
    total_target_pairs = len(filtered[["search_query", "item_id"]].drop_duplicates())
    for fold_id, (fit, targets) in enumerate(_pair_holdout_folds(filtered, n_folds=2)):
        target_map = targets.assign(_q=targets["search_query"].map(normalize_query)).groupby("_q")["item_id"].agg(lambda x: set(x.astype(str))).to_dict()
        target_queries = query_view(targets)
        print(f"Generating leakage-free final training candidates fold {fold_id + 1}/2 ({len(target_queries):,} target queries).", flush=True)
        train_pool, train_features, _ = build_candidate_pool(fit, target_queries, items, score_cache, max_pool=500)
        fold_rows = labeled_candidate_rows(
            target_queries, train_pool, train_features, items, target_map,
            negatives_per_positive=10, seed=SEED + fold_id,
        )
        # Duplicate query keys across folds are separate ranking groups.
        fold_rows["query_key"] = fold_rows["query_key"].astype(str) + f"\u241e{fold_id}"
        training_frames.append(fold_rows)
        del fit, targets, target_queries, train_pool, train_features, fold_rows
        gc.collect()
    train_rows = pd.concat(training_frames, ignore_index=True)
    if train_rows.empty or train_rows["label"].nunique() != 2:
        raise RuntimeError("Final training candidate set must contain both positive and hard-negative labels")
    training_pair_rows = len(train_rows)
    training_positive_rows = int(train_rows["label"].sum())
    print(f"Training LambdaRank: {training_pair_rows:,} candidate pairs, {training_positive_rows:,} positive labels from {total_target_pairs:,} distinct train pairs.", flush=True)
    feature_columns = [column for column in train_rows.columns if column not in {"query_key", "item_id", "label"}]
    model = fit_ranker(train_rows, feature_columns, seed=SEED)
    del train_rows, training_frames
    gc.collect()

    # Only train positives from the returnable catalog enter retrieval history.
    # Benchmark relevance labels are never loaded.
    print(f"Generating candidates for {len(benchmark_view):,} benchmark query rows.", flush=True)
    # The retrieval history needs only positive pairs whose item can actually
    # be returned from this fixed candidate catalog. This removes query texts
    # that could contribute no candidate and keeps the index memory bounded.
    pools, retrieval_features, _ = build_candidate_pool(filtered, benchmark_view, items, score_cache, max_pool=500)
    candidate_rows = feature_frame(benchmark_view, pools, items, retrieval_features)
    if candidate_rows.empty:
        raise RuntimeError("No candidates generated for benchmark queries")
    ranked = rerank_candidates(model, candidate_rows, feature_columns, top_k=50)

    answers_by_query = {str(key): " ".join(str(item_id) for item_id in values[:50]) for key, values in ranked.items()}
    output = queries[["query_id"]].copy()
    output["answer"] = output["query_id"].astype(str).map(answers_by_query).fillna("")
    output["query_id"] = output["query_id"].astype("string")
    output.to_csv(ROOT / "answer.csv", index=False, encoding="utf-8", lineterminator="\n")
    validate_answer(ROOT / "answer.csv", ROOT / "benchmark_queries.parquet", ROOT / "benchmark_items.parquet")
    print(f"Wrote and validated {ROOT / 'answer.csv'} ({len(output):,} queries).", flush=True)

    report = [
        "# Final inference run",
        "",
        "- Retrieval: exact query + similar query word/character TF-IDF + BM25 + character item TF-IDF, round-robin deduplicated to at most 500 candidates.",
        "- Reranker: LightGBM LambdaRank, fixed seed 42, query-level groups; two-fold pair-disjoint cross-fitting makes every catalog-covered train pair a target once, with that pair excluded from its retrieval fit.",
        f"- Training source rows in benchmark catalog: {len(filtered):,}.",
        f"- Distinct catalog-covered train query-item pairs used as fold targets: {total_target_pairs:,}; generated candidate training pairs: {training_pair_rows:,} ({training_positive_rows:,} positive labels); hard negatives are sampled at up to 1:10.",
        f"- Benchmark query rows: {len(queries):,}; distinct normalized query texts: {queries['search_query'].map(normalize_query).nunique():,}.",
        f"- Candidate pairs scored at inference: {len(candidate_rows):,}.",
        "- Benchmark labels were not loaded or used.",
        "",
    ]
    (ROOT / "FINAL_RUN_REPORT.md").write_text("\n".join(report), encoding="utf-8")


if __name__ == "__main__":
    main()
